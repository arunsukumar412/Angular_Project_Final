import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-saved-jobs',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    RouterModule
  ],
  templateUrl: './saved-jobs.component.html',
  styleUrl: './saved-jobs.component.css'
})
export class SavedJobsComponent implements OnInit {
  isLoading = false;
  savedJobs = [
    {
      id: '1',
      title: 'Software Engineer',
      company: 'Tech Corp',
      location: 'San Francisco, CA',
      description: 'Develop and maintain web applications using modern frameworks.',
      dateSaved: '2025-07-01',
      salary: '$120,000 - $150,000',
      type: 'Full-time'
    },
    {
      id: '2',
      title: 'Data Scientist',
      company: 'Data Insights Inc.',
      location: 'New York, NY',
      description: 'Analyze large datasets to provide business insights.',
      dateSaved: '2025-07-02',
      salary: '$130,000 - $160,000',
      type: 'Full-time'
    },
    {
      id: '3',
      title: 'Product Manager',
      company: 'Innovate Solutions',
      location: 'Remote',
      description: 'Lead product development and strategy for SaaS products.',
      dateSaved: '2025-07-03',
      salary: '$110,000 - $140,000',
      type: 'Remote'
    }
  ];

  constructor(private snackBar: MatSnackBar) {}

  ngOnInit() {
    this.loadJobs();
  }

  loadJobs() {
    this.isLoading = true;
    // Simulate async loading
    setTimeout(() => {
      this.isLoading = false;
    }, 1000);
  }

  removeJob(jobId: string) {
    this.isLoading = true;
    // Simulate async removal
    setTimeout(() => {
      this.savedJobs = this.savedJobs.filter(job => job.id !== jobId);
      this.isLoading = false;
      this.snackBar.open('Job removed from saved list', 'Close', { duration: 3000 });
    }, 500);
  }

  viewJobDetails(jobId: string) {
    // Simulate navigation to job details (could be implemented with router)
    this.snackBar.open(`Viewing details for job ID: ${jobId}`, 'Close', { duration: 3000 });
  }
}
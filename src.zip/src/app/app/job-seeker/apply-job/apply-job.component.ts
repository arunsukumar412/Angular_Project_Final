import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatListModule } from '@angular/material/list';

@Component({
  selector: 'app-apply-job',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatListModule
  ],
  templateUrl: './apply-job.component.html',
  styleUrl: './apply-job.component.css'
})
export class ApplyJobComponent implements OnInit {
  applicationForm: FormGroup;
  isLoading = false;
  selectedJob = { id: '', title: '', company: '' };
  resumes = [
    { id: '1', name: 'resume-2025.pdf' },
    { id: '2', name: 'resume-updated.pdf' }
  ];
  jobs = [
    { id: 'JOB-ABC123', title: 'Software Developer', company: 'Tech Corp' },
    { id: 'JOB-XYZ789', title: 'Data Scientist', company: 'Data Insights Inc.' },
    { id: 'JOB-QWE456', title: 'Product Manager', company: 'Innovate Solutions' },
    { id: 'JOB-RTY789', title: 'UX Designer', company: 'Creative Labs' }
  ];
  applications = [
    { id: 'APP-001', jobId: 'JOB-ABC123', jobTitle: 'Software Developer', company: 'Tech Corp', date: '2025-06-30' },
    { id: 'APP-002', jobId: 'JOB-XYZ789', jobTitle: 'Data Scientist', company: 'Data Insights Inc.', date: '2025-07-01' },
    { id: 'APP-003', jobId: 'JOB-QWE456', jobTitle: 'Product Manager', company: 'Innovate Solutions', date: '2025-07-02' },
    { id: 'APP-004', jobId: 'JOB-RTY789', jobTitle: 'UX Designer', company: 'Creative Labs', date: '2025-07-03' }
  ];

  constructor(private fb: FormBuilder, private snackBar: MatSnackBar) {
    this.applicationForm = this.fb.group({
      jobId: [{ value: '', disabled: true }, Validators.required],
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.pattern(/^\d{10}$/)]],
      resumeId: ['', Validators.required],
      notes: ['', Validators.maxLength(500)]
    });
  }

  ngOnInit() {
    this.loadProfile();
    this.setRandomJob();
  }

  loadProfile() {
    this.isLoading = true;
    setTimeout(() => {
      this.applicationForm.patchValue({
        firstName: 'John',
        lastName: 'Doe',
        email: 'john.doe@example.com',
        phone: '1234567890'
      });
      this.isLoading = false;
    }, 1000);
  }

  setRandomJob() {
    const randomJob = this.jobs[Math.floor(Math.random() * this.jobs.length)];
    this.selectedJob = randomJob;
    this.applicationForm.patchValue({ jobId: randomJob.id });
  }

  submitApplication() {
    if (this.applicationForm.valid) {
      this.isLoading = true;
      setTimeout(() => {
        this.applications.unshift({
          id: `APP-${Date.now()}`,
          jobId: this.selectedJob.id,
          jobTitle: this.selectedJob.title,
          company: this.selectedJob.company,
          date: new Date().toISOString().split('T')[0]
        });
        this.isLoading = false;
        this.snackBar.open(`Application submitted for ${this.selectedJob.title} at ${this.selectedJob.company}`, 'Close', { duration: 3000 });
        this.resetForm();
      }, 1000);
    } else {
      this.snackBar.open('Please fill all required fields correctly', 'Close', { duration: 3000 });
    }
  }

  resetForm() {
    this.applicationForm.reset();
    this.applicationForm.patchValue({
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      phone: '1234567890'
    });
    this.setRandomJob();
    this.snackBar.open('Form reset', 'Close', { duration: 3000 });
  }
}
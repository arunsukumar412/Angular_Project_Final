import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JobseekerSidebarComponent } from '../jobseeker-sidebar/jobseeker-sidebar.component';
import { CommonModule } from '@angular/common';
interface Application {
  id: number;
  jobTitle: string;
  company: string;
  appliedDate: Date;
  status: string;
  notes?: string;
}

interface Interview {
  id: number;
  position: string;
  type: string;
  interviewer: string;
  scheduledTime: Date;
  status: string;
  meetingLink?: string;
  phoneNumber?: string;
}

@Component({
  selector: 'app-jobseeker-dashboard',
  templateUrl: './jobseeker-dashboard.component.html',
  styleUrls: ['./jobseeker-dashboard.component.css'],
  imports:[CommonModule,JobseekerSidebarComponent]
})
export class JobseekerDashboardComponent implements OnInit {
  sidebarOpen = true;
  userInitials = 'AR';
  userName = 'Arun';
  
  stats = {
    totalApplications: 12,
    applicationsGrowth: 5,
    interviewsScheduled: 3,
    interviewsGrowth: 10
  };

  recentApplications: Application[] = [
    {
      id: 1,
      jobTitle: 'Senior UX Designer',
      company: 'TechCorp',
      appliedDate: new Date('2023-06-15'),
      status: 'Under Review',
      notes: 'HR screening scheduled'
    },
    {
      id: 2,
      jobTitle: 'Product Manager',
      company: 'Innovate Inc',
      appliedDate: new Date('2023-06-10'),
      status: 'Interview',
      notes: 'Technical round next week'
    },
    {
      id: 3,
      jobTitle: 'Frontend Developer',
      company: 'WebSolutions',
      appliedDate: new Date('2023-06-05'),
      status: 'Rejected',
      notes: 'Position filled internally'
    }
  ];

  upcomingInterviews: Interview[] = [
    {
      id: 1,
      position: 'Senior UX Designer',
      type: 'Technical Round',
      interviewer: 'Sarah Johnson (Lead Designer)',
      scheduledTime: new Date('2023-06-20T14:30:00'),
      status: 'Scheduled',
      meetingLink: 'https://meet.example.com/xyz123'
    },
    {
      id: 2,
      position: 'Product Manager',
      type: 'HR Screening',
      interviewer: 'Michael Chen (HR Manager)',
      scheduledTime: new Date('2023-06-22T10:00:00'),
      status: 'Scheduled',
      phoneNumber: '+1 (555) 123-4567'
    }
  ];

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Check screen size and adjust sidebar
    this.checkScreenSize();
    window.addEventListener('resize', () => this.checkScreenSize());
  }

  checkScreenSize(): void {
    this.sidebarOpen = window.innerWidth >= 768;
  }

  toggleSidebar(): void {
    this.sidebarOpen = !this.sidebarOpen;
  }

  getStatusClass(status: string): string {
    switch(status.toLowerCase()) {
      case 'under review':
        return 'bg-blue-100 text-blue-800';
      case 'interview':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'offered':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  getInterviewStatusClass(status: string): string {
    switch(status.toLowerCase()) {
      case 'scheduled':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'rescheduled':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }

  prepareForInterview(interview: Interview): void {
    console.log('Preparing for interview:', interview);
    // Implement preparation logic
  }

  joinInterview(interview: Interview): void {
    if (interview.meetingLink) {
      window.open(interview.meetingLink, '_blank');
    } else if (interview.phoneNumber) {
      window.location.href = `tel:${interview.phoneNumber}`;
    }
  }

  rescheduleInterview(interview: Interview): void {
    console.log('Rescheduling interview:', interview);
    // Implement reschedule logic
  }

  logout(): void {
    console.log('User logged out');
    this.router.navigate(['/login']);
  }
}
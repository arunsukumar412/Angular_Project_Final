import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { RouterModule } from '@angular/router';
import { MatListModule } from '@angular/material/list';

@Component({
  selector: 'app-history',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    RouterModule,
    MatListModule
  ],
  templateUrl: './history.component.html',
  styleUrl: './history.component.css'
})
export class HistoryComponent implements OnInit {
  isLoading = false;
  applications = [
    { id: 'APP-001', jobId: 'JOB-ABC123', jobTitle: 'Software Developer', company: 'Tech Corp', date: '2025-06-30' },
    { id: 'APP-002', jobId: 'JOB-XYZ789', jobTitle: 'Data Scientist', company: 'Data Insights Inc.', date: '2025-07-01' },
    { id: 'APP-003', jobId: 'JOB-QWE456', jobTitle: 'Product Manager', company: 'Innovate Solutions', date: '2025-07-02' },
    { id: 'APP-004', jobId: 'JOB-RTY789', jobTitle: 'UX Designer', company: 'Creative Labs', date: '2025-07-03' },
    { id: 'APP-005', jobId: 'JOB-ASD321', jobTitle: 'DevOps Engineer', company: 'Cloud Systems', date: '2025-07-04' }
  ];

  constructor() {}

  ngOnInit() {
    this.isLoading = true;
    setTimeout(() => {
      this.applications = this.applications.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      this.isLoading = false;
    }, 1000);
  }

  getApplicationCount(): number {
    return this.applications.length;
  }
}
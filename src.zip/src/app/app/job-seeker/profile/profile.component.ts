import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { NgModule } from '@angular/core';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule
  ],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup;
  isEditing = false;
  isLoading = false;
  userProfile: any = {
    id: '1',
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    phone: '1234567890',
    dateOfBirth: '1990-01-01',
    address: '123 Main St, City, Country',
    occupation: 'Software Developer',
    company: 'Tech Corp',
    website: 'https://johndoe.com',
    bio: 'Passionate developer with 5+ years of experience',
    country: 'USA',
    language: 'English',
    timezone: 'EST',
    github: 'johndoe',
    linkedin: 'johndoe',
    twitter: 'johndoe',
    skills: 'Angular, TypeScript, JavaScript',
    education: 'BS Computer Science, XYZ University',
    experience: 'Senior Developer at Tech Corp',
    interests: 'Coding, Reading, Hiking'
  };
  profilePicture: string | ArrayBuffer | null = null;

  constructor(
    private fb: FormBuilder,
    private snackBar: MatSnackBar
  ) {
    this.profileForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.pattern(/^\d{10}$/)]],
      dateOfBirth: [''],
      address: [''],
      occupation: [''],
      company: [''],
      website: [''],
      bio: ['', [Validators.maxLength(500)]],
      country: [''],
      language: [''],
      timezone: [''],
      github: [''],
      linkedin: [''],
      twitter: [''],
      skills: [''],
      education: [''],
      experience: [''],
      interests: ['']
    });
  }

  ngOnInit() {
    this.loadProfile();
  }

  loadProfile() {
    this.isLoading = true;
    // Simulate async loading
    setTimeout(() => {
      this.profileForm.patchValue(this.userProfile);
      this.isLoading = false;
    }, 1000);
  }

  toggleEdit() {
    this.isEditing = !this.isEditing;
    if (!this.isEditing) {
      this.profileForm.patchValue(this.userProfile);
    }
  }

  saveProfile() {
    if (this.profileForm.valid) {
      this.isLoading = true;
      // Simulate async save
      setTimeout(() => {
        this.userProfile = { ...this.profileForm.value };
        this.isEditing = false;
        this.isLoading = false;
        this.snackBar.open('Profile updated successfully', 'Close', { duration: 3000 });
      }, 1000);
    } else {
      this.snackBar.open('Please fill all required fields correctly', 'Close', { duration: 3000 });
    }
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = () => {
        this.profilePicture = reader.result;
        // Simulate async picture update
        setTimeout(() => {
          this.snackBar.open('Profile picture updated', 'Close', { duration: 3000 });
        }, 500);
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  resetForm() {
    this.profileForm.reset();
    this.profileForm.patchValue(this.userProfile);
  }

  exportProfile() {
    const profileData = JSON.stringify(this.userProfile);
    const blob = new Blob([profileData], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'profile.json';
    a.click();
    window.URL.revokeObjectURL(url);
  }

  copyProfileLink() {
    const profileUrl = `${window.location.origin}/profile/${this.userProfile.id}`;
    navigator.clipboard.writeText(profileUrl);
    this.snackBar.open('Profile link copied!', 'Close', { duration: 3000 });
  }
}
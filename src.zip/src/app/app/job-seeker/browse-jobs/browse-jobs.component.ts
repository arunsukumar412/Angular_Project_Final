import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSidenavModule } from '@angular/material/sidenav';

@Component({
  selector: 'app-browse-jobs',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatPaginatorModule,
    MatSidenavModule
  ],
  templateUrl: './browse-jobs.component.html',
  styleUrl: './browse-jobs.component.css'
})
export class BrowseJobsComponent implements OnInit {
  isLoading = false;
  searchQuery = '';
  filterType = '';
  filterLocation = '';
  filterSalary = '';
  filterCategory = '';
  filterExperience = '';
  remoteOnly = false;
  sortBy = 'relevance';
  currentPage = 0;
  pageSize = 10;
  isDarkMode = false;
  showFilters = false;

  jobs = [
    {
      id: '1',
      title: 'Software Engineer',
      company: 'Tech Corp',
      location: 'San Francisco, CA',
      description: 'Develop web applications using Angular and TypeScript.',
      salary: '$120,000 - $150,000',
      type: 'Full-time',
      isSaved: false,
      postedDate: '2025-06-30',
      deadline: '2025-08-01',
      category: 'Engineering',
      experience: 'Mid-level',
      tags: ['Angular', 'TypeScript', 'JavaScript'],
      logo: 'https://via.placeholder.com/50',
      status: 'Active',
      rating: 4.5,
      source: 'Indeed'
    },
    {
      id: '2',
      title: 'Data Scientist',
      company: 'Data Insights Inc.',
      location: 'New York, NY',
      description: 'Analyze datasets using Python and machine learning.',
      salary: '$130,000 - $160,000',
      type: 'Full-time',
      isSaved: false,
      postedDate: '2025-07-01',
      deadline: '2025-07-30',
      category: 'Data Science',
      experience: 'Senior',
      tags: ['Python', 'Machine Learning', 'SQL'],
      logo: 'https://via.placeholder.com/50',
      status: 'Active',
      rating: 4.7,
      source: 'LinkedIn'
    },
    {
      id: '3',
      title: 'Product Manager',
      company: 'Innovate Solutions',
      location: 'Remote',
      description: 'Lead SaaS product development and strategy.',
      salary: '$110,000 - $140,000',
      type: 'Remote',
      isSaved: false,
      postedDate: '2025-07-02',
      deadline: '2025-08-15',
      category: 'Management',
      experience: 'Senior',
      tags: ['Product Management', 'Agile', 'SaaS'],
      logo: 'https://via.placeholder.com/50',
      status: 'Active',
      rating: 4.3,
      source: 'Company Website'
    },
    {
      id: '4',
      title: 'UX Designer',
      company: 'Creative Labs',
      location: 'Austin, TX',
      description: 'Design user-friendly interfaces for mobile apps.',
      salary: '$100,000 - $130,000',
      type: 'Full-time',
      isSaved: false,
      postedDate: '2025-07-03',
      deadline: '2025-08-10',
      category: 'Design',
      experience: 'Junior',
      tags: ['UI/UX', 'Figma', 'Prototyping'],
      logo: 'https://via.placeholder.com/50',
      status: 'Active',
      rating: 4.6,
      source: 'Glassdoor'
    }
  ];

  constructor(private snackBar: MatSnackBar) {}

  ngOnInit() {
    this.loadJobs();
  }

  loadJobs() {
    this.isLoading = true;
    // Simulate async loading
    setTimeout(() => {
      this.isLoading = false;
    }, 1000);
  }

  toggleSaveJob(jobId: string) {
    this.isLoading = true;
    setTimeout(() => {
      const job = this.jobs.find(j => j.id === jobId);
      if (job) {
        job.isSaved = !job.isSaved;
        this.snackBar.open(
          job.isSaved ? 'Job saved successfully' : 'Job removed from saved list',
          'Close',
          { duration: 3000 }
        );
      }
      this.isLoading = false;
    }, 500);
  }

  viewJobDetails(jobId: string) {
    this.snackBar.open(`Viewing details for job ID: ${jobId}`, 'Close', { duration: 3000 });
  }

  applyForJob(jobId: string) {
    this.snackBar.open(`Applying for job ID: ${jobId}`, 'Close', { duration: 3000 });
  }

  shareJob(jobId: string) {
    const job = this.jobs.find(j => j.id === jobId);
    if (job) {
      const jobUrl = `${window.location.origin}/job/${jobId}`;
      navigator.clipboard.writeText(jobUrl);
      this.snackBar.open('Job link copied to clipboard', 'Close', { duration: 3000 });
    }
  }

  getFilteredJobs() {
    let filteredJobs = [...this.jobs];

    // Apply search query
    if (this.searchQuery) {
      const query = this.searchQuery.toLowerCase();
      filteredJobs = filteredJobs.filter(
        job =>
          job.title.toLowerCase().includes(query) ||
          job.description.toLowerCase().includes(query) ||
          job.company.toLowerCase().includes(query)
      );
    }

    // Apply filters
    if (this.filterType) {
      filteredJobs = filteredJobs.filter(job => job.type === this.filterType);
    }
    if (this.filterLocation) {
      filteredJobs = filteredJobs.filter(job =>
        job.location.toLowerCase().includes(this.filterLocation.toLowerCase())
      );
    }
    if (this.filterSalary) {
      filteredJobs = filteredJobs.filter(job =>
        job.salary.toLowerCase().includes(this.filterSalary.toLowerCase())
      );
    }
    if (this.filterCategory) {
      filteredJobs = filteredJobs.filter(job => job.category === this.filterCategory);
    }
    if (this.filterExperience) {
      filteredJobs = filteredJobs.filter(job => job.experience === this.filterExperience);
    }
    if (this.remoteOnly) {
      filteredJobs = filteredJobs.filter(job => job.type === 'Remote');
    }

    // Apply sorting
    if (this.sortBy === 'date-desc') {
      filteredJobs.sort((a, b) => new Date(b.postedDate).getTime() - new Date(a.postedDate).getTime());
    } else if (this.sortBy === 'date-asc') {
      filteredJobs.sort((a, b) => new Date(a.postedDate).getTime() - new Date(b.postedDate).getTime());
    } else if (this.sortBy === 'salary-desc') {
      filteredJobs.sort((a, b) => {
        const aSalary = parseInt(a.salary.split('-')[1].replace(/[^0-9]/g, ''));
        const bSalary = parseInt(b.salary.split('-')[1].replace(/[^0-9]/g, ''));
        return bSalary - aSalary;
      });
    } else if (this.sortBy === 'salary-asc') {
      filteredJobs.sort((a, b) => {
        const aSalary = parseInt(a.salary.split('-')[1].replace(/[^0-9]/g, ''));
        const bSalary = parseInt(b.salary.split('-')[1].replace(/[^0-9]/g, ''));
        return aSalary - bSalary;
      });
    }

    // Apply pagination
    const start = this.currentPage * this.pageSize;
    return filteredJobs.slice(start, start + this.pageSize);
  }

  getSavedJobsCount() {
    return this.jobs.filter(job => job.isSaved).length;
  }

  clearFilters() {
    this.searchQuery = '';
    this.filterType = '';
    this.filterLocation = '';
    this.filterSalary = '';
    this.filterCategory = '';
    this.filterExperience = '';
    this.remoteOnly = false;
    this.sortBy = 'relevance';
    this.currentPage = 0;
    this.snackBar.open('Filters cleared', 'Close', { duration: 3000 });
  }

  handlePageEvent(event: PageEvent) {
    this.currentPage = event.pageIndex;
    this.pageSize = event.pageSize;
  }

  toggleDarkMode() {
    this.isDarkMode = !this.isDarkMode;
    this.snackBar.open(this.isDarkMode ? 'Dark mode enabled' : 'Light mode enabled', 'Close', { duration: 3000 });
  }

  exportJobs() {
    const jobsData = JSON.stringify(this.jobs);
    const blob = new Blob([jobsData], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'jobs.json';
    a.click();
    window.URL.revokeObjectURL(url);
    this.snackBar.open('Job list exported', 'Close', { duration: 3000 });
  }

  toggleFilters() {
    this.showFilters = !this.showFilters;
  }
}
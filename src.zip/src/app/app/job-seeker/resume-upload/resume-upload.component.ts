import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-resume-upload',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    RouterModule
  ],
  templateUrl: './resume-upload.component.html',
  styleUrl: './resume-upload.component.css'
})
export class ResumeUploadComponent implements OnInit {
  isLoading = false;
  resumes: { id: string; name: string; size: number; dateUploaded: string; data: string }[] = [
    {
      id: '1',
      name: 'resume-2025.pdf',
      size: 1258291, // ~1.2MB
      dateUploaded: '2025-07-01',
      data: '' // Base64 or URL data (simulated)
    },
    {
      id: '2',
      name: 'resume-updated.pdf',
      size: 943718, // ~0.9MB
      dateUploaded: '2025-07-03',
      data: ''
    }
  ];

  constructor(private snackBar: MatSnackBar) {}

  ngOnInit() {
    this.loadResumes();
  }

  loadResumes() {
    this.isLoading = true;
    // Simulate async loading
    setTimeout(() => {
      this.isLoading = false;
    }, 1000);
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      // Validate file type and size
      if (file.type !== 'application/pdf') {
        this.snackBar.open('Only PDF files are allowed', 'Close', { duration: 3000 });
        return;
      }
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        this.snackBar.open('File size must be less than 5MB', 'Close', { duration: 3000 });
        return;
      }

      this.isLoading = true;
      const reader = new FileReader();
      reader.onload = () => {
        // Simulate async upload
        setTimeout(() => {
          this.resumes.push({
            id: Date.now().toString(),
            name: file.name,
            size: file.size,
            dateUploaded: new Date().toISOString().split('T')[0],
            data: reader.result as string
          });
          this.isLoading = false;
          this.snackBar.open('Resume uploaded successfully', 'Close', { duration: 3000 });
        }, 1000);
      };
      reader.readAsDataURL(file);
    }
  }

  downloadResume(resume: { name: string; data: string }) {
    const link = document.createElement('a');
    link.href = resume.data;
    link.download = resume.name;
    link.click();
    this.snackBar.open(`Downloading ${resume.name}`, 'Close', { duration: 3000 });
  }

  deleteResume(resumeId: string) {
    this.isLoading = true;
    // Simulate async deletion
    setTimeout(() => {
      this.resumes = this.resumes.filter(resume => resume.id !== resumeId);
      this.isLoading = false;
      this.snackBar.open('Resume deleted successfully', 'Close', { duration: 3000 });
    }, 500);
  }
}
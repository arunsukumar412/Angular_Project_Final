import { Component } from '@angular/core';

@Component({
  selector: 'app-job-details',
  imports: [],
  templateUrl: './job-details.component.html',
  styleUrl: './job-details.component.css'
})
export class JobDetailsComponent {

}

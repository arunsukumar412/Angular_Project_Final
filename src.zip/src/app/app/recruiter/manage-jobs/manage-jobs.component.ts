import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-jobs',
  imports: [],
  templateUrl: './manage-jobs.component.html',
  styleUrl: './manage-jobs.component.css'
})
export class ManageJobsComponent {

}

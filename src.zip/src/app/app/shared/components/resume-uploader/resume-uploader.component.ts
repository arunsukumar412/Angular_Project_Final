import { Component } from '@angular/core';

@Component({
  selector: 'app-resume-uploader',
  imports: [],
  templateUrl: './resume-uploader.component.html',
  styleUrl: './resume-uploader.component.css'
})
export class ResumeUploaderComponent {

}

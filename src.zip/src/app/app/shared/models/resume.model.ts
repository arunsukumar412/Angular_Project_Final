export class Resume {
}

import { Resume } from './resume.model';

describe('Resume', () => {
  it('should create an instance', () => {
    expect(new Resume()).toBeTruthy();
  });
});

export class Recruiter {
}

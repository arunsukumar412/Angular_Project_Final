import { Recruiter } from './recruiter.model';

describe('Recruiter', () => {
  it('should create an instance', () => {
    expect(new Recruiter()).toBeTruthy();
  });
});

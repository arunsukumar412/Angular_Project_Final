import { Component, OnInit } from '@angular/core';
import { formatDate } from '@angular/common';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { NgModule } from '@angular/core';
import { MathAbsPipe } from '../../job-seeker/math-abs.pipe';


interface Report {
  id: number;
  title: string;
  type: string;
  date: string;
  status: string;
  user: string;
  [key: string]: any;
}

interface Notification {
  id: number;
  title: string;
  message: string;
  time: Date;
  actions?: boolean;
}

interface ActivityLog {
  message: string;
  timestamp: Date;
}

@Component({
  selector: 'app-admin-report',
  templateUrl: './admin-report-management.component.html',
  styleUrls: ['./admin-report-management.component.css'],
  imports:[SidebarComponent,CommonModule,FormsModule,ReactiveFormsModule]
})
export class AdminReportManagementComponent  implements OnInit {
  // User and app metadata
  currentUser: string = 'Admin User';
  userProfileImage: string = 'https://via.placeholder.com/32';
  currentYear: number = new Date().getFullYear();
  appVersion: string = '1.0.0';
  currentDate: Date = new Date();

  // Report data
  reports: Report[] = [
    { id: 1, title: 'Sales Report Q1', type: 'Sales', date: '2025-03-01', status: 'Completed', user: 'John Doe' },
    { id: 2, title: 'User Activity Report', type: 'User', date: '2025-06-15', status: 'Pending', user: 'Jane Smith' },
    { id: 3, title: 'System Performance', type: 'System', date: '2025-07-01', status: 'In Progress', user: 'Admin' },
    // Add more mock reports as needed
  ];
  filteredReports: Report[] = [...this.reports];
  paginatedReports: Report[] = [];
  reportTypes: string[] = ['All', 'Sales', 'User', 'System'];
  selectedReport: string = 'All';

  // Dashboard summary
  totalReports: number = this.reports.length;
  activeUsers: number = 150;
  systemHealth: number = 95;
  recentActivities: number = 42;
  reportGrowth: number = 12.5;
  userGrowth: number = 8.3;
  systemHealthChange: number = 2.1;

  // Pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = Math.ceil(this.filteredReports.length / this.itemsPerPage);

  // Sorting
  currentSortColumn: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  // Filters
  searchQuery: string = '';
  filterDate: string = '';

  // UI toggles
  showUserDropdown: boolean = false;
  showNotifications: boolean = false;
  showExportAdvanced: boolean = false;
  unreadNotifications: number = 3;

  // Export options
  exportFormats: string[] = ['CSV', 'PDF', 'Excel', 'JSON'];
  selectedColumns: string[] = [];

  // Activity log
  activityLog: ActivityLog[] = [
    { message: 'Sales Report Q1 generated', timestamp: new Date('2025-07-07T08:30:00') },
    { message: 'User Activity Report exported', timestamp: new Date('2025-07-06T15:45:00') },
  ];

  // Notifications
  notifications: Notification[] = [
    { id: 1, title: 'New Report Available', message: 'Sales Report Q2 is ready for review.', time: new Date('2025-07-07T09:00:00'), actions: true },
    { id: 2, title: 'System Update', message: 'System maintenance scheduled for tonight.', time: new Date('2025-07-07T08:00:00'), actions: false },
    { id: 3, title: 'User Feedback', message: 'New feedback received from Jane Smith.', time: new Date('2025-07-06T16:30:00'), actions: true },
  ];

  constructor() {}

  ngOnInit(): void {
    this.updatePaginatedReports();
  }

  // Toggle UI elements
  toggleSidebar(): void {
    // Implement sidebar toggle logic for mobile
  }

  toggleUserDropdown(): void {
    this.showUserDropdown = !this.showUserDropdown;
  }

  toggleNotifications(): void {
    this.showNotifications = !this.showNotifications;
  }

  toggleExportAdvanced(): void {
    this.showExportAdvanced = !this.showExportAdvanced;
  }

  logout(): void {
    // Implement logout logic
    console.log('User logged out');
  }

  // Report filtering and sorting
  filterReports(): void {
    let filtered = [...this.reports];

    if (this.searchQuery) {
      filtered = filtered.filter(report =>
        report.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        report.user.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }

    if (this.filterDate) {
      filtered = filtered.filter(report => report.date === this.filterDate);
    }

    if (this.selectedReport !== 'All') {
      filtered = filtered.filter(report => report.type === this.selectedReport);
    }

    this.filteredReports = filtered;
    this.totalPages = Math.ceil(this.filteredReports.length / this.itemsPerPage);
    this.currentPage = 1;
    this.updatePaginatedReports();
  }

  sortData(column: string): void {
    if (this.currentSortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.currentSortColumn = column;
      this.sortDirection = 'asc';
    }

    this.filteredReports.sort((a, b) => {
      const valueA = a[column];
      const valueB = b[column];
      if (typeof valueA === 'string' && typeof valueB === 'string') {
        return this.sortDirection === 'asc'
          ? valueA.localeCompare(valueB)
          : valueB.localeCompare(valueA);
      }
      return this.sortDirection === 'asc'
        ? valueA - valueB
        : valueB - valueA;
    });

    this.updatePaginatedReports();
  }

  isSortable(column: string): boolean {
    return ['id', 'title', 'date', 'status', 'user'].includes(column);
  }

  // Pagination
  updatePaginatedReports(): void {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    this.paginatedReports = this.filteredReports.slice(start, end);
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedReports();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedReports();
    }
  }

  firstPage(): void {
    this.currentPage = 1;
    this.updatePaginatedReports();
  }

  lastPage(): void {
    this.currentPage = this.totalPages;
    this.updatePaginatedReports();
  }

  goToPage(page: number): void {
    this.currentPage = page;
    this.updatePaginatedReports();
  }

  getPageNumbers(): number[] {
    const pages = [];
    const maxPages = 5; // Show up to 5 page numbers
    let startPage = Math.max(1, this.currentPage - 2);
    let endPage = Math.min(this.totalPages, startPage + maxPages - 1);

    if (endPage - startPage < maxPages - 1) {
      startPage = Math.max(1, endPage - maxPages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    return pages;
  }

  onItemsPerPageChange(): void {
    this.totalPages = Math.ceil(this.filteredReports.length / this.itemsPerPage);
    this.currentPage = 1;
    this.updatePaginatedReports();
  }

  // Table utilities
  getTableHeaders(): string[] {
    if (this.filteredReports.length > 0) {
      return Object.keys(this.filteredReports[0]).filter(key => key !== 'id');
    }
    return ['title', 'type', 'date', 'status', 'user'];
  }

  formatCellValue(value: any, key: string): string {
    if (key === 'date') {
      return formatDate(value, 'mediumDate', 'en-US');
    }
    return value;
  }

  // Report actions
  viewDetails(report: Report): void {
    console.log('Viewing details for report:', report);
  }

  downloadSingle(report: Report): void {
    console.log('Downloading report:', report);
  }

  exportReport(format: string): void {
    console.log(`Exporting reports in ${format} format`);
  }

  exportAllReports(): void {
    console.log('Exporting all reports');
  }

  scheduleExport(): void {
    console.log('Scheduling export');
  }

  toggleExportColumn(column: string): void {
    const index = this.selectedColumns.indexOf(column);
    if (index === -1) {
      this.selectedColumns.push(column);
    } else {
      this.selectedColumns.splice(index, 1);
    }
  }

  isColumnSelected(column: string): boolean {
    return this.selectedColumns.includes(column);
  }

  // Quick actions
  generateSummaryReport(): void {
    console.log('Generating summary report');
  }

  sendToEmail(): void {
    console.log('Sending report to email');
  }

  printReport(): void {
    window.print();
  }

  openAnalytics(): void {
    console.log('Opening analytics');
  }

  // Notification handling
  handleNotificationAction(notification: Notification, action: string): void {
    console.log(`Handling ${action} for notification:`, notification);
    if (action === 'dismiss') {
      this.notifications = this.notifications.filter(n => n.id !== notification.id);
      this.unreadNotifications = this.notifications.length;
    }
  }

  markAllAsRead(): void {
    this.notifications = [];
    this.unreadNotifications = 0;
  }

  // Activity log
  clearActivityLog(): void {
    this.activityLog = [];
  }

  // Data refresh
  refreshData(): void {
    console.log('Refreshing data');
    this.filterReports();
  }

  clearFilters(): void {
    this.searchQuery = '';
    this.filterDate = '';
    this.selectedReport = 'All';
    this.filterReports();
  }

  onReportChange(): void {
    this.filterReports();
  }
}
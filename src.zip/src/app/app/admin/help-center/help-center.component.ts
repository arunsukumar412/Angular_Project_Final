import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms'; // For ngModel
import { SidebarComponent } from '../sidebar/sidebar.component';

interface HelpSection {
  id: string;
  title: string;
  content: string;
}

interface FAQ {
  id: number;
  question: string;
  answer: string;
  expanded: boolean;
}

interface Contact {
  date: string;
  type: string;
}

@Component({
  selector: 'app-help-center',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './help-center.component.html',
  styleUrls: ['./help-center.component.css']
})
export class HelpCenterComponent implements OnInit {
  activeSection: string = 'faq';
  isSidebarCollapsed: boolean = false;
  currentYear: number = new Date().getFullYear();
  helpSections: HelpSection[] = [
    { id: 'faq', title: 'Frequently Asked Questions', content: 'Answers to common queries about using the portal.' },
    { id: 'guides', title: 'User Guides', content: 'Step-by-step instructions for key features.' },
    { id: 'support', title: 'Support', content: 'Contact options and support ticket creation.' }
  ];
  searchQuery: string = '';
  filteredSections: HelpSection[] = [];
  faqs: FAQ[] = [
    { id: 1, question: 'How do I reset my password?', answer: 'Go to login and click Forgot Password.', expanded: false },
    { id: 2, question: 'What browsers are supported?', answer: 'Chrome, Firefox, Edge, Safari.', expanded: false }
  ];
  recentArticles: { title: string, section: string }[] = [
    { title: 'Password Reset Guide', section: 'faq' },
    { title: 'Content Management Basics', section: 'guides' }
  ];
  videoUrl: string = '';
  feedback: string = '';
  selectedLanguage: string = 'en';
  contactHistory: Contact[] = [
    { date: '2025-07-04', type: 'Email' },
    { date: '2025-07-03', type: 'Phone' }
  ];
  showNotification: boolean = true;
  isDarkMode: boolean = false;
  showTableOfContents: boolean = true;
  bookmarkedSection: string = '';
  progress: number = 0;
  showHelpfulRating: boolean = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.filteredSections = [...this.helpSections];
    const urlParams = window.location.href.split('#')[1];
    this.activeSection = urlParams || 'faq';
  }

  toggleSidebar(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.toggle('-translate-x-full', this.isSidebarCollapsed);
    }
  }

  setActiveSection(sectionId: string): void {
    this.activeSection = sectionId;
    window.location.hash = sectionId;
    if (window.innerWidth < 768) {
      this.toggleSidebar();
    }
  }

  // Feature 1: Search Bar
  filterSections(): void {
    this.filteredSections = this.helpSections.filter(section =>
      section.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      section.content.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
  }

  // Feature 2: Filtered Content Display (Handled by *ngFor in template)

  // Feature 3: Expandable FAQ Items
  toggleFAQ(faqId: number): void {
    this.faqs = this.faqs.map(faq => faq.id === faqId ? { ...faq, expanded: !faq.expanded } : faq);
  }

  // Feature 4: Downloadable Guides
  downloadGuide(sectionId: string): void {
    const link = document.createElement('a');
    link.href = `guides/${sectionId}.pdf`; // Placeholder, replace with actual URL
    link.download = `${sectionId}-guide.pdf`;
    link.click();
  }

  // Feature 5: Live Chat Button
  startLiveChat(): void {
    window.open('https://livechat.genworx.com', '_blank');
  }

  // Feature 6: No Results Message (Handled by *ngIf in template)

  // Feature 7: Recent Articles (Static data, can be dynamic)

  // Feature 8: Video Tutorials
  loadVideoTutorial(): void {
    this.videoUrl = 'https://example.com/tutorial.mp4'; // Replace with actual URL
  }

  // Feature 9: Feedback Form
  submitFeedback(): void {
    console.log('Feedback submitted:', this.feedback);
    this.feedback = '';
  }

  // Feature 10: Language Switcher
  changeLanguage(): void {
    console.log('Language changed to:', this.selectedLanguage);
    // Implement language translation logic
  }

  // Feature 11: Contact History (Static data, can be dynamic)

  // Feature 12: Notification Banner
  dismissNotification(): void {
    this.showNotification = false;
  }

  // Feature 13: Dark Mode Toggle
  toggleDarkMode(): void {
    document.body.classList.toggle('dark', this.isDarkMode);
  }

  // Feature 14: Table of Contents
  toggleTableOfContents(): void {
    this.showTableOfContents = !this.showTableOfContents;
  }

  // Feature 15: Bookmark Section
  bookmarkSection(): void {
    this.bookmarkedSection = this.activeSection;
  }

  // Feature 16: Rate Helpfulness
  rateHelpful(isHelpful: boolean): void {
    this.showHelpfulRating = true;
    console.log('Rated as helpful:', isHelpful);
  }

  // Feature 17: Glossary (Static content, can be expanded)

  // Feature 18: Share Link
  shareLink(): void {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => alert('Link copied to clipboard!'));
  }

  // Feature 19: Progress Tracker
  updateProgress(): void {
    this.progress = Math.min(this.progress + 10, 100); // Example increment
  }

  // Feature 20: Ask AI Assistant
  askAIAssistant(): void {
    console.log('Opening AI Assistant for section:', this.activeSection);
    // Integrate with Grok 3 API or a custom service
  }

  openPolicy(type: string): void {
    console.log(`Opening ${type} policy at ${new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })}`);
    this.router.navigate([`/policy/${type}`]);
  }

  openContact(): void {
    console.log(`Opening contact page at ${new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })}`);
    this.router.navigate(['/contact']);
  }
}
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface ChatMessage {
  text: string;
  isUser: boolean;
}

@Component({
  selector: 'app-chat-assistant',
  templateUrl: './chat-assistant.component.html',
  styleUrls: ['./chat-assistant.component.css'],
  imports:[CommonModule,FormsModule]
})
export class ChatAssistantComponent implements OnInit {
  isChatOpen: boolean = false;
  userName: string = 'User';
  messages: ChatMessage[] = [
    { text: `Hello ${this.userName}! I'm your GenWorx career assistant. How can I help you today?`, isUser: false }
  ];
  newMessage: string = '';
  quickQuestions: string[] = [
    'Interview tips',
    'Application status',
    'Resume feedback',
    'Company culture'
  ];

  ngOnInit(): void {
    // Simulate fetching user name from sessionStorage or a service
    this.userName = sessionStorage.getItem('userName') || 'User';
    this.messages = [
      { text: `Hello ${this.userName}! I'm your GenWorx career assistant. How can I help you today?`, isUser: false }
    ];
  }

  toggleChat(): void {
    this.isChatOpen = !this.isChatOpen;
  }

  sendMessage(): void {
    if (this.newMessage.trim()) {
      // Add user message
      this.messages.push({ text: this.newMessage, isUser: true });
      
      // Simulate bot response
      const botResponse = this.getBotResponse(this.newMessage);
      if (botResponse) {
        setTimeout(() => {
          this.messages.push({ text: botResponse, isUser: false });
          // Scroll to bottom of chat
          this.scrollToBottom();
        }, 500); // Small delay for realism
      }

      this.newMessage = '';
      this.scrollToBottom();
    }
  }

  selectQuickQuestion(question: string): void {
    this.newMessage = question;
    this.sendMessage();
  }

  private getBotResponse(message: string): string {
    const lowerMessage = message.toLowerCase();
    if (lowerMessage.includes('interview tips')) {
      return 'Prepare by researching the company, practicing common questions, and using the STAR method (Situation, Task, Action, Result) to showcase your skills.';
    } else if (lowerMessage.includes('application status')) {
      return 'I don’t have access to real-time application data. Please check your email or the GenWorx career portal for updates.';
    } else if (lowerMessage.includes('resume feedback')) {
      return 'Ensure your resume is concise (1-2 pages), tailored to the job, and highlights measurable achievements. Use action verbs and quantify results where possible.';
    } else if (lowerMessage.includes('company culture')) {
      return 'GenWorx likely promotes innovation and collaboration, but I don’t have specific details. Check their official website or employee reviews on platforms like Glassdoor.';
    } else {
      return 'I’m here to help! Could you clarify or ask about interview tips, application status, resume feedback, or company culture?';
    }
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      const chatMessages = document.getElementById('chat-messages');
      if (chatMessages) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
      }
    }, 0);
  }
}
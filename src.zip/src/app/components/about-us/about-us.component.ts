import { Component } from '@angular/core';
import { ChatAssistantComponent } from "../../chat-assistant/chat-assistant.component";

@Component({
  selector: 'app-about-us',
  imports: [ChatAssistantComponent],
  templateUrl: './about-us.component.html',
  styleUrl: './about-us.component.css'
})
export class AboutUsComponent {

}
